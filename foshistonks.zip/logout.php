<script>
    sessionStorage.clear();
    window.location.replace('http://localhost/foshistonks/index.php');
</script>